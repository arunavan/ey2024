package com.ey.service;

import com.ey.dto.CustomerLoginDTO;
import com.ey.exception.InfyBankException;

public interface CustomerLoginService {
	public String authenticateCustomer(CustomerLoginDTO customerLogin) throws InfyBankException;
}
