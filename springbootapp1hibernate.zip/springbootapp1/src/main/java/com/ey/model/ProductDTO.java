package com.ey.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.validation.constraints.Max;

public class ProductDTO {
	@NotNull(message="cannot be blank")
	Integer id;
	@NotNull(message="cannot be blank")
	@Size
	String name;
	@NotNull(message="cannot be blank")
	@Max(1000)
	Double qty;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "ProductDTO [id=" + id + ", name=" + name + ", qty=" + qty + "]";
	}
	
	

}
