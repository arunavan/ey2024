package com.ey;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


import com.ey.entity.Products;

public class App 
{
	private static final SessionFactory SESSION_FACTORY;

	static {

		try {
			SESSION_FACTORY = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Session Factory could not be created." + ex);
			throw new ExceptionInInitializerError();
		}

	}

	public static SessionFactory getSessionFactory() {
		return SESSION_FACTORY;
	}
    public static void main( String[] args )
    {
    	Session session = getSessionFactory().openSession();
				
		Products p=new Products();
		p.setId(3);
		p.setName("box");
		p.setQty(80.00);
         session.beginTransaction();
         session.save(p); //insert 
         // commit transaction
         session.getTransaction().commit();
        //transaction.rollback();
    }
}
