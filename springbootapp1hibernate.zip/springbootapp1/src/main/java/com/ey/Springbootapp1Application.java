package com.ey;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan({"com.ey.entity"})
public class Springbootapp1Application implements CommandLineRunner
{

	public static void main(String[] args) {
		SpringApplication.run(Springbootapp1Application.class, args);
	}

	public void run(String... args) {
		System.out.println(" Console springBoot application");
	}
}
