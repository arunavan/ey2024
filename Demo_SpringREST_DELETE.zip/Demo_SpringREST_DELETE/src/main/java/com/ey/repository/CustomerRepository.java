package com.ey.repository;


import org.springframework.data.repository.CrudRepository;

import com.ey.entity.Customer;
//builtin interface - crud, find findByID,findAll,save,delete deleteByID
public interface CustomerRepository extends CrudRepository<Customer, Integer> 
{

}
