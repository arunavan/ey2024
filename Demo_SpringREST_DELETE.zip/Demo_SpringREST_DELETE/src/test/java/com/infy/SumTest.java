package com.infy;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ey.api.Sum;

class SumTest {

	@Test
	void test() {
		Sum s=new Sum();
		assertEquals(10,s.getsum(4, 6));
		//fail("Not yet implemented");
	}

}
