package com.ey.model;


public class ProductDTO {
		Integer id;
	String name;
	Double qty;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "ProductDTO [id=" + id + ", name=" + name + ", qty=" + qty + "]";
	}
	
	

}
