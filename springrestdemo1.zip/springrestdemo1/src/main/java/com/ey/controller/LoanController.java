package com.ey.controller;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ey.model.ProductDTO;



@RestController
public class LoanController {
	
	@GetMapping("/product")   //   http:localhost:8083/getemi  - requestURL    - GET  - requestMethod  
  //POST,DELETE,PUT,PATCH,OPTIONS
	public ResponseEntity<ProductDTO> getProduct() {
		
		ProductDTO p=new ProductDTO();
		p.setId(101);
		p.setName("Bag");
		p.setQty(90.00);
		//java to JSON , XML,html, text 
		return new ResponseEntity<>(p,HttpStatus.OK);
	}
	@PostMapping("/add")   //body
	public ResponseEntity<ProductDTO>  addProduct(@RequestBody  ProductDTO p) {
		
		return new ResponseEntity<>(p,HttpStatus.CREATED);
		
	}
	
	

	@PutMapping("/update/{id}")
	public ResponseEntity<Integer>  updateProduct(@PathVariable Integer id) {
		return new ResponseEntity<>(id,HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Integer>   deleteProduct(@PathVariable Integer id) {
		return new ResponseEntity<>(id,HttpStatus.OK);
	}

	
	
	
}
