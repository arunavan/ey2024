package com.ey.dto;

public enum CustomerType {
	SILVER, GOLD, PLATINUM;
}
