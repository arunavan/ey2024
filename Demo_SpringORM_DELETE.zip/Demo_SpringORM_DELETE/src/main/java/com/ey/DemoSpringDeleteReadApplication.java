package com.ey;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.ey.dto.CustomerDTO;
import com.ey.dto.CustomerType;
import com.ey.exception.InfyBankException;
import com.ey.service.CustomerServiceImpl;

@SpringBootApplication
public class DemoSpringDeleteReadApplication implements CommandLineRunner {

	public static final Log LOGGER = LogFactory.getLog(DemoSpringDeleteReadApplication.class);

	@Autowired
	CustomerServiceImpl customerService;

	@Autowired
	Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringDeleteReadApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		 addCustomer();
		//updateCustomer();
		//getCustomer();
	
	//	deleteCustomer();
		getallCustomers();
		
	}

	public void getCustomer() throws InfyBankException {
		try {
			CustomerDTO customerDTO = customerService.getCustomer(5);
		//	System.out.println(customerDTO);
			LOGGER.info(customerDTO);
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(environment.getProperty(e.getMessage(),
						"Something went wrong. Please check log file for more details."));
		}
	}
	
	public void  getallCustomers() throws InfyBankException{
		List<CustomerDTO> customerDTOlist = customerService.getallCustomers();
		 customerDTOlist.stream().forEach(c->System.out.println(c));
		 LOGGER.info(environment.getProperty("UserInterface.ALL_SUCCESS"));
	}

	public void addCustomer() {
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(11);
		customerDTO.setEmailId("EYUser9@infy.com");
		customerDTO.setName("EYUSer10");
		customerDTO.setDateOfBirth(LocalDate.of(1980, 4, 22));
		customerDTO.setCustomerType(CustomerType.SILVER);

		try {
			customerService.addCustomer(customerDTO);
			LOGGER.info(environment.getProperty("UserInterface.INSERT_SUCCESS"));
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(environment.getProperty(e.getMessage(),
						"Something went wrong. Please check log file for more details."));
		}
	}

	public void updateCustomer() {
		try {
			customerService.updateCustomer(3, "EYyser123@ey.com");
			LOGGER.info(environment.getProperty("UserInterface.UPDATE_SUCCESS"));
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(environment.getProperty(e.getMessage(),
						"Something went wrong. Please check log file for more details."));
		}
	}

	public void deleteCustomer() {
		try {
			customerService.deleteCustomer(9);
			LOGGER.info(environment.getProperty("UserInterface.DELETE_SUCCESS"));
		} catch (Exception e) {
			if (e.getMessage() != null)
				LOGGER.info(environment.getProperty(e.getMessage(),
						"Something went wrong. Please check log file for more details."));
		}
	}
}
