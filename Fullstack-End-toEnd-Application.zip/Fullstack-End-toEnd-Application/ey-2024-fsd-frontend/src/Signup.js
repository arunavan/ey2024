
var Signup = () =>(
    <div>

        <h1> customer signup Page</h1>
        <form>
        <input type="text" name="n"/>
           <input type="submit"></input>
           </form>
    </div>
)

export default Signup;