package com.ey;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HemoController {
	
	@RequestMapping("/home")
	public String getHomePage(ModelMap map) {
		
		//LocalDate date1=LocalDate.now();
		map.addAttribute("date", LocalDate.now());
		
		return "home";
	}
	
	@RequestMapping(value="/msg", method = RequestMethod.GET)
	public String getMessage() {
		return "msg";
	}
	
	@RequestMapping(value = "/user", method = RequestMethod.POST)
	//	@PostMapping("/user")
		public String user(@Validated User user, Model model) {
			model.addAttribute("x", user.getUserName());//mapping 
			return "user";   //result this view 
		}

}
