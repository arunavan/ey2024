package com.ey.autowiring.test;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.ey.autowiring.service com.ey.autowiring.repository")
public class AutowiringConfig {

}
