package com.ey;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;


import com.ey.entity.Products;

public class App 
{

    public static void main( String[] args )
    {
    	Session session =  new Configuration().configure().buildSessionFactory().openSession();
				
		Products p=new Products();
		p.setId(6);
		p.setName("table5");
		p.setQty(80.00);
		/*
        //insert
		session.beginTransaction();
         session.save(p); //insert query
        session.getTransaction().commit();
        
        //update
    	session.beginTransaction();
        Products p1=(Products)session.get(Products.class, 3); //select
      //  p1.setName("xxx");
        p1.setQty(200.00);   //update
        session.getTransaction().commit();
        
        //delete
        session.beginTransaction();
        Products p2=(Products)session.get(Products.class, 4); //select
       session.delete(p2);    //delete
        session.getTransaction().commit();
        */
		//Native Query
		//Query q=session.createNativeQuery("select * from products"); //HQL  select * from products
        
		//HQL query
        //Query q=session.createQuery("from Products p"); //HQL  select * from products
		//Named query
	 //   Query q=session.createNamedQuery("eyquery"); //HQL  select * from products
	   


		Query q=session.createQuery("from Products p where p.name='box'"); //
		List<Products> plist=q.getResultList();
        //for(Object p3: plist)
        	//System.out.println((Products)p3);
        	
        plist.forEach(System.out::println);
        
        System.out.println(" get single object====");
        Products p5=(Products)session.load(Products.class,5); //select
        System.out.println(p5);
        
    }
}
