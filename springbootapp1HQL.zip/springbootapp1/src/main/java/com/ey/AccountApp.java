package com.ey;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

import com.ey.entity.Account;
import com.ey.entity.Products;

public class AccountApp 
{

    public static void main( String[] args )
    {
    	Session session =  new Configuration().configure().buildSessionFactory().openSession();
		// trascient
    	Account account=new Account();
    	account.setAcNo(12345);
    	account.setName("Raj");
    	account.setBalance(15000.00);
    	session.beginTransaction();
    	session.save(account); //persistent state , managed state
    	session.getTransaction().commit();
    	
		
    }
}
