package com.ey.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Account {
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		Integer acNo;
		@Column
		String name;
		@Column
		Double balance;
		public Account() {}
		public Integer getAcNo() {
			return acNo;
		}
		public void setAcNo(Integer acNo) {
			this.acNo = acNo;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Double getBalance() {
			return balance;
		}
		public void setBalance(Double balance) {
			this.balance = balance;
		}
		@Override
		public String toString() {
			return "Account [acNo=" + acNo + ", name=" + name + ", balance=" + balance + "]";
		}
		
		
}
