//import logo from './logo.svg';
//import './App.css';



/*
function App() {
  return (
    <div className="App">
      
     <h1>single Page App </h1>
    </div>
  );
}

export default App;
*/


/*  Class Component*/
/*
import React,{ Component } from "react";
import Signup from "./Signup";
class App  extends Component{
  render(){
    return ( 
     <div>
          <h1> Parent- Root Component </h1>
          <h1>   EY Technologies </h1>
          <br></br>
          <div>
                <div><Signin/> </div>
                <Signup/>
          </div>
          
      </div>
    );
  }
}
export default App;

class Signin extends Component{
render(){
  return(

       <div> singin Component </div>
  );
}

}
*/
// funcitonal component


/*
function App(){
return (
<div>
      <h1> My first react functional compoennt</h1>
</div>
);
}
 export default App;
*/

//arrow function 
/*
export default App => {
  return (
    <div>
          <h1> My first react functional compoennt</h1>
    </div>
    );
}













*/


/*
import React,{ Component} from "react"
class App extends Component{  //state is class local mutable , props - parent-immutable
  constructor() {
    super()
    this.state = {
       n : 100//n state 

    }
     this.inc = this.inc.bind(this)   //register function 
     this.dec = this.dec.bind(this) 
 };
 inc(){
  this.setState( { n: this.state.n + 10 } )
 }
 dec(){
  this.setState( { n: this.state.n - 10 } )
 }

 valiate(){
  console.log("validate is called");
 }
  render(){
    return (
            <div className="App">
           <h2> Lifecycle methods & EventBinding - Class Component</h2>
          <h2> Couter Application</h2>
           <button onClick={ this.valiate}> Validate</button>
          <button onClick = {this.inc}>INCREMENT ++ </button>
          <button onClick = {this.dec}>Decrement -- </button>
           { this.state.n }
        
          <Content myVal= { this.state.n }  xVal= { 5  }    yVal={ 89 } />


            </div>     
             );  }
}

export default App;

class Content extends Component{
constructor() {
  super();
}

render(){
  return(
<div>
       <h1>  this is from child : Content</h1>
       {  this.props.myVal+10}
       {this.props.myVal} -
       {this.props.xVal} -
       {this.props.yVal}

</div>

  );
}
}

*/
//functional component , useState, useEffect
/*
import { useState, useEffect } from "react";

const App = () => {
  const [count, setCount] = useState(0);//initialization
  //change detection
  useEffect(() => {    console.log(`You have clicked the button ${count} times`)  }
 ,[]
  
  );   
  //[],[count]  as second argument  to suppress side effects like life cycle methods
  return (
    <div>  
      <button onClick={() => setCount(count + 1)}> ++ </button> 
      <button onClick={()=>setCount(count-1)} > --</button>
      {count }
      
    </div>
  );
}
export default App;
*/
// to update state using useState
/*
import { useState } from "react";
 function App() {
  const [name, setName] = useState("EY Traine");
  const [email,setEmail]= useState("eyuser@ey.com");
  const changeName = () => {
    setName("EY Employee");
  };
  const updateEmail=() => {
    setEmail("eyemployee@ey.com");
  }
  return (
    <div>
      <p>My name is {name}</p>
      <button onClick={changeName}> update name </button>
      <div>
          <h1> Email is : { email }</h1>
          <button onClick={updateEmail} >updateEmail</button>
          <button onClick={()=> setEmail("eyemp@ey.com")} >updateEmail</button>
      </div>
    </div>
  );
}
export default App

*/
//
// form input using recat hook and functional component
/*
import  {useState} from 'react';
function App() {
    const [input , setInput] = useState({  name: ''  })
    const inputsHandler = (e) =>{ setInput( {[e.target.name]: e.target.value} )  
                                }
    const submitButton = () =>{ 
      alert(input.name)   
      if(input.name.length>5)
       console.log("valid")
       else
       console.log("Invalid")
    }
    return ( <div>
        <div>      <input  type="text"  name="name" 
                    onChange={inputsHandler} 
                    placeholder="Name" 
                    value={input.name}/>
                    <br/>
                  <button onClick={submitButton}>Submit Now</button>
        </div>
        <br></br>
        <div>Name given by you : {input.name}</div>
        </div>
    )
}
export default App;

*/
/*
import React from 'react';
import Content from './Content';

class App extends React.Component {
   constructor(props) {
      super(props);
      
      this.state = {n: 0 }
      this.inc = this.inc.bind(this)
   };
   inc() {
      this.setState({n: this.state.n + 1})
   }
   render() {
      return (
         <div>
            <button onClick = {this.inc}>INCREMENT</button>  Value:  {this.state.n}
            <Content myNumber = {this.state.n} />
         </div>
      );
   }
}
export default App;
*/

/*
import React, {useState} from 'react';
function App() {  //state
const [inputField , setInputField] = useState({
    first_name: '',
    last_name: '',
    gmail: ''
})
const inputsHandler = (e) =>{
    const { name, value } = e.target;
   setInputField((prevState) => ({...prevState,[name]: value,}));
}
const submitButton = () =>{
    alert(inputField.first_name+ " "+inputField.last_name+" "+inputField.gmail)
    console.log(inputField.first_name+ " "+inputField.last_name+" "+inputField.gmail)
}
 return (
     <div>
      <h1 > React inline css</h1>  
         <input 
        type="text" 
        name="first_name" 
        onChange={inputsHandler} 
        placeholder="First Name" 
        value={inputField.first_name}/>
       <br/>
        <input 
        type="text" 
        name="last_name" 
        onChange={inputsHandler} 
        placeholder="Last Name" 
        value={inputField.last_name}/>
        <br/>
        <input 
        type="email" 
        name="gmail" 
        onChange={inputsHandler} 
        placeholder="Gmail" 
        value={inputField.gmail}/>

        <br/>
        <button onClick={submitButton}>Submit Now</button>
        <div>
        First_Name: {inputField.first_name}
        LAst_Name : {inputField.last_name}
        Email id:   {inputField.gmail}
        </div>

    </div>
)
}

export default App;
*/

/*
import { useForm } from "react-hook-form"; //npm install react-hook-form
const App = () => {
 const { handleSubmit, register, formState: { errors } } = useForm();
  const onSubmit = values => alert(values.email + " " + values.password);
 return (
   <div className="app">
     <form onSubmit={handleSubmit(onSubmit)}>
       <h1>Register</h1>
       <div className="formInput">
         <label>Email</label>
         <input
           type="email"
           {...register("email", {
             required: "Email cannot be empty",
             pattern: {
               value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
               message: "invalid email address"
             }
           })}
         />
         {errors.email && errors.email.message}
       </div>you
       <div className="formInput">
         <label>Password</label>
         <input
           type="password"
           {...register("password", {
             required: "PAssword cannot be empty",
             pattern: {
               value: /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/,
               message: "Password requirements: 8-20 characters, 1 number, 1 letter, 1 symbol."
             }
           })}
         />
         {errors.password && errors.password.message}
       </div>
       <button type="submit">Submit</button>
     </form>
   </div>
 );
};


export default App;

*/
//child component

/*
function App() {
  return (
    <div className="App">
          <Header/>
           Welcome to React training
           <Message city='Hyderabad'/>
     </div>
  );
}

// <ADPMessage />
function Message({city}) {
  return <p>  <h1> { city }</h1> </p>
}
*/
/*
function Header(){
  return <h1> EY,INDIA</h1>
}


*/





/*
event handling

const handleClickEvent = (event) => {
  console.log('button clicked');
}

function App() {
  return <button onClick={handleClickEvent}>Click here</button>
}

*/


/*
const { useEffect, useState } = React

const CounterWithNameAndSideEffect = () => {
  const [count, setCount] = useState(0)

  useEffect(() => {
    console.log(`You clicked ${count} times`)
  })

  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>Click me</button>
    </div>
  )
}

*/
/*
import React, { useState } from 'react';
import './App.css';
import AddUser from './AddUser';
import UserList from './UserList';
import { AppContext } from './context';

function App() {
	const [ users, setUsers ] = useState([]);
	
	const dispatchUserEvent = (actionType, payload) => {
		switch (actionType) {
			case 'ADD_USER':
				setUsers([ ...users, payload.newUser ]);
				return;
			case 'REMOVE_USER':
				setUsers(users.filter(user => user.id !== payload.userId));
				return;
			default:
				return;
		}
	};

	return (
		<div className="App">
			<AppContext.Provider value={{ users, dispatchUserEvent }}>
				<AddUser />
				<UserList />
			</AppContext.Provider>
		</div>
	);
}

export default App;
*/




/*
import React from 'react'
export default class App extends React.Component { //stateful

   
 render(){
   return (
   <div>
         Learn React with version React18s with class component
       
    </div>
 
);
 }
}




import FunApp1 from './FunApp1'

import React,{useState} from 'react'

function App() {
  return (
    <div>
      
          Learn React with version React18s
          <FunApp1 name='ADPUSer123'/>
          <Tutorial/>
          <MyComponent/>
       
    </div>
  );
}


/*
var App=()=>(
  
   <div>    Learn React with version React18s using arrow function
     </div>
 )
export default App;







*/
/*
import Menu from './Menu';
import React,{useState} from 'react'
import Home from './Home'
import Form from './Form'
import Clock from './Clock'
import FunApp1 from './FunApp1'
class App extends React.Component{
  render(){
    return(
      <div>
          <h1> Class Component</h1>
          <Menu city='Hyderabad'/>
          <Home/>
          <Form/>
          <Clock/>
          <FunApp1 name='ADPUSer123'/>
          <Tutorial/>
          <MyComponent/>
          
      </div>

    );
  }
}

export default App;


function Course(props) { //props
   return <h2>Avaiable course is  { props.cname }!</h2>;
 }
 
 function Tutorial() {

   return (
     <>
       <h1>Course available now </h1>
       <Course cname="JavaFullstack" />
     </>
   );
 }
 


const MyComponent = (props) => {
const [value, setValue] = useState(1);  //state
return (
<div>
   <p>{value}</p>
   <button onClick={() => setValue((value + 1))}>Increment Value</button>
</div>
);
}


/*
class App extends React.Component {
  constructor(props) {
     super(props);
     
     this.state = {
        data: 0
     }
     this.setNewNumber = this.setNewNumber.bind(this)
  };
  setNewNumber() {
     this.setState({data: this.state.data + 1})
  }
  render() {
     return (
        <div>
           <button onClick = {this.setNewNumber}>INCREMENT</button>
           <Content myNumber = {this.state.data}></Content>
        </div>
     );
  }
}
class Content extends React.Component {
  componentWillMount() {
     console.log('Component WILL MOUNT!')
  }
  componentDidMount() {
     console.log('Component DID MOUNT!')
  }
  componentWillReceiveProps(newProps) {    
     console.log('Component WILL RECIEVE PROPS!')
  }
  shouldComponentUpdate(newProps, newState) {
     return true;
  }
  componentWillUpdate(nextProps, nextState) {
     console.log('Component WILL UPDATE!');
  }
  componentDidUpdate(prevProps, prevState) {
     console.log('Component DID UPDATE!')
  }
  componentWillUnmount() {
     console.log('Component WILL UNMOUNT!')
  }
  render() {
     return (
        <div>
           <h3>{this.props.myNumber}</h3>
        </div>
     );
  }
}
*/


/*


import React from "react"
class App extends React.Component{

render(){
  return(
    <div>    Main page </div>
  );

}

}
export default App;

*/

/*
import React from 'react';
//import Button from "react-bootstrap"
import {  Routes,  Route ,Link} from 'react-router-dom';
import About from './components/About';
import Contact from './components/Contact';
import Home from './components/Home';
import { Button } from 'react-bootstrap';
//npm install react-router-dom
export default function App() {
  return (
      <div>
        
        <nav>
          <ul>
            <li>  <Link to="/">Home</Link> </li>
            <li>  <Link to="/about">About</Link></li>
            <li>  <Link to="/contact">Contact</Link></li>
          </ul>
        </nav>
        <hr />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact/:id" element={<Contact/>}/> 
        </Routes>
       </div>
          );
}
          */
/*http://localhost:3001/contact/123  */

/*

import React, { useState, Fragment } from 'react'
import AddUserForm from './forms/AddUserForm'
import EditUserForm from './forms/EditUserForm'
import UserTable from './tables/UserTable'

const App = () => {
	// Data
	const usersData = [
		{ id: 1001, name: 'Tania',salary : 50000, department: 'IT' },
		{ id: 1002, name: 'Craig',salary : 90000, department: 'IT' },
		{ id: 1003, name: 'Ben',salary : 80000, department: 'IT' },
	]

	const initialFormState = { id: null, name: '', salary: '',department:'' }

	// Setting state
	const [ users, setUsers ] = useState(usersData)
	const [ currentUser, setCurrentUser ] = useState(initialFormState)
	const [ editing, setEditing ] = useState(false)

	// CRUD operations
	const addUser = user => {
		user.id = users.length + 1
		setUsers([ ...users, user ])
	}

	const deleteUser = id => {
		setEditing(false)

		setUsers(users.filter(user => user.id !== id))
	}

	const updateUser = (id, updatedUser) => {
		setEditing(false)

		setUsers(users.map(user => (user.id === id ? updatedUser : user)))
	}

	const editRow = user => {
		setEditing(true)

		setCurrentUser({ id: user.id, name: user.name,salary: user.salary,department:user.department })
	}

	return (
		<div className="container">
			<h1>CRUD App with Hooks</h1>
			<div className="flex-row">
				<div className="flex-large">
					{editing ? (
						<Fragment>
							<h2>Edit user</h2>
							<EditUserForm
								editing={editing}
								setEditing={setEditing}
								currentUser={currentUser}
								updateUser={updateUser}
							/>
						</Fragment>
					) : (
						<Fragment>
							<h2>Add user</h2>
							<AddUserForm addUser={addUser} />
						</Fragment>
					)}
				</div>
				<div className="flex-large">
					<h2>View users</h2>
					<UserTable users={users} editRow={editRow} deleteUser={deleteUser} />
				</div>
			</div>
		</div>
	)
}

export default App
*/

import useFetchData from './useFetchData'
function App() {  //parent 
    const { data } = useFetchData("https://api.github.com/users");
  return (
      <div>
          <p> learn react </p>
          {data && (
            data.map((user) =>(
                <div className="text-white" key={user.id}>

                    <p> {user.login} </p>

                     <p> { user.url } </p>
                    

                    
                </div>
            ))
          )}
                           <div>
                      <NameList/>

                      <NumberList/>

                      <ProductList/>                  
                      </div>
   
      </div>
  )
}
export default App;


function NameList() {  
  const myLists = ['ES5', 'ES6', 'Typescript', 'React'];   
  const listItems = myLists.map((x) =>  <li>{x}</li>    );  
  return (  
    <div>  
          <h2>React Map Example</h2>  
              <ul>{listItems}</ul>  
    </div>  
  );  
}  



function NumberList(props) {  
  const numbers =  [3, 2, 6,4,8];  
  const listItems = numbers.map((number) =>   <li > {number*number}</li> );  
  return (  
    <div>  
      <h2>React Map Example</h2>  
          <ul> {listItems} </ul>  
    </div>  
  );  
}  

function  ProductList(props) {
const  product = [  
  { id: 101, title: 'Pen', price: '99.00' },  
  { id: 102, title: 'Bag', price: '99.00' },  
  { id: 103, title: 'Book', price: '99.00' },  
];  
const  productitems=product.map(p => <h3> {p.id} : { p.title} : {p.price}  </h3> );
return (
<div>
           {productitems}
</div>
);
}