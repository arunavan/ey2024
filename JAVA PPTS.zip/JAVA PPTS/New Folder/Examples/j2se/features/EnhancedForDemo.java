//Enhanced For Demo

public class EnhancedForDemo
{
    public static void main(String[] args)
    {   int[] intArray = {10,20,30,40,50};
        System.out.println("Array Elements are");
	for(int i:intArray)
        { System.out.println(i);
	}
    }
}