class Outer12
{
	// example for static nested classes
	static class Inner12
	{
		public static void main(String args[])
		{
			System.out.println("nested class main method");
		}
	}
}