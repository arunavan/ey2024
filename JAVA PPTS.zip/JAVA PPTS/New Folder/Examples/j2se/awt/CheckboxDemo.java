import java.awt.*;

public class CheckboxDemo extends Frame
{
		Checkbox cb1 = new Checkbox("Reading", true);
		Checkbox cb2 = new Checkbox("Music", true);
		Checkbox cb3 = new Checkbox("Painting", false);
		Checkbox cb4 = new Checkbox("Movies", false);
		Checkbox cb5 = new Checkbox("Dancing", false);

		Label lbl = new Label("What's your hobby?");

		public CheckboxDemo(String s)
		{
				super(s);
				setLayout(new GridLayout(6,1));
				add(lbl);
				add(cb1);
				add(cb2);
				add(cb3);
				add(cb4);
				add(cb5);
		}

		public static void main(String[] args) 
		{
			CheckboxDemo fd = new CheckboxDemo("Displaying Checkboxes...");
			fd.setSize(400, 400);
			fd.show();
		}
}