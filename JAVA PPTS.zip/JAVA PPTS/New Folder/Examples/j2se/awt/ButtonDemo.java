 import java.awt.*;

public class ButtonDemo extends Frame
{
		Button btnB1 = new Button("Create");
		Button btnB2 = new Button("Update");
		Button btnB3 = new Button("Delete");

		public ButtonDemo(String s)
		{
				super(s);
				setLayout(new FlowLayout());
				add(btnB1);
				add(btnB3);
				add(btnB2);
				setSize(400, 400);
				setVisible(true);

		}

		public static void main(String[] args) 
		{
			ButtonDemo fd = new ButtonDemo("The three little Button Components");
		//	fd.setSize(400, 400);
	//		fd.show();
		//	fd.setVisible(true);
		}
}