import java.awt.*;

class FrameDemo extends Frame
{
		private GridBagLayout gbl;
		private GridBagConstraints gbc;

		public FrameDemo(String s)
		{
			super(s);

			gbl = new GridBagLayout();
			setLayout(gbl);								// set Frame layout
			gbc = new GridBagConstraints();				// instantiate constraints

			TextArea ta1 = new TextArea("TextArea1", 5, 10);
			TextArea ta2 = new TextArea("TextArea2", 2, 2);

			// Create a Choice and add elements to it
			Choice ch = new Choice();
			ch.add("Gold");
			ch.add("Silver");
			ch.add("Bronze");
			ch.add("Iron");

			TextField tf = new TextField("TextField");

			Button b1 = new Button("Button1");
			Button b2 = new Button("Button2");
			Button b3 = new Button("Button3");

			// weightx and weighty for ta1 are both 0; the default anchor for all
			// components is CENTER: the default
			gbc.fill= GridBagConstraints.BOTH;
			addComponent(ta1,0,0,1,3);

			// weightx and weighty for b1 are both 0: the default
			gbc.fill= GridBagConstraints.HORIZONTAL;
			addComponent(b1,0,1,2,1);

			// weightx and weighty for ch are both 0: the default fill is HORIZONTAL
			addComponent(ch,2,1,2,1);

			// b2
			gbc.weightx=1000;				// can grow wider
			gbc.weighty=1;					// can grow taller
			gbc.fill= GridBagConstraints.BOTH;
			addComponent(b2,1,1,1,1);

			// b3
			gbc.weightx=0;					// can grow wider
			gbc.weighty=0;					// can grow taller
			addComponent(b3,1,2,1,1);

			// weightx and weighty for tf are both 0: the default fill is BOTH
			addComponent(tf,3,0,2,1);

			// weightx and weighty for ta2 are both 0: the default fill is BOTH
			addComponent(ta2,3,2,1,1);
		}

		private void addComponent(Component c, int row, int col, int width, int height)
		{
			gbc.gridx = col;				// set gridx
			gbc.gridy = row;				// set gridy
			gbc.gridwidth = width;			// set gridwidth
			gbc.gridheight = height;		// set gridheight
			gbl.setConstraints(c, gbc);		// set constraints
			add(c);							// add component
		}
}

public class GridBagFrameDemo
{
		public static void main(String args[])
		{
			FrameDemo gbf = new FrameDemo("Grid Bag Layout");
			gbf.setSize(300, 150);
			gbf.setVisible(true);
		}
}