import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code=ChoiceControlDemo width=350 height=200></applet>*/

public class ChoiceControlDemo extends Applet implements ItemListener
{
		Choice ch1, ch2;
		String msg = "";

		public void init()
		{
				ch1 = new Choice();
				ch2 = new Choice();

				//add item to ch1 list				
				ch1.add("Amithab Bhachan");
				ch1.add("Bobby Deol");
				ch1.add("Sharukh Khan");
				ch1.add("Rithik Roshan");
				ch1.add("Leonardo DiCaprio");

				//add item to ch2 list				
				ch2.add("Jaya Bhaduri");
				ch2.add("Hemamalini");
				ch2.add("Kajol");
				ch2.add("Priti Zinta");
				ch2.add("Shermila");

				ch2.select("Kajol");

				add(ch1);
				add(ch2);

				ch1.addItemListener(this);
				ch2.addItemListener(this);
		}

		public void itemStateChanged(ItemEvent ie) 
		{
				repaint();
		}

		// Display current state of the checkboxes
		public void paint(Graphics g)
		{
				msg = "Selected Item from Choice ch1	 :	";

				msg += ch1.getSelectedItem();

				g.drawString(msg, 6, 100);

				msg = "Selected Item from Choice ch2	 :	";

				msg += ch2.getSelectedItem();

				g.drawString(msg, 6, 120);
		}
}