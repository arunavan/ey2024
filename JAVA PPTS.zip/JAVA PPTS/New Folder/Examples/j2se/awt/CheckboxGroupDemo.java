import java.awt.*;

public class CheckboxGroupDemo extends Frame
{
		CheckboxGroup cbg = new CheckboxGroup();

		Checkbox cb1 = new Checkbox("Undergraduate", cbg, true);
		Checkbox cb2 = new Checkbox("Graduate", cbg, true);
		Checkbox cb3 = new Checkbox("Post Graduate", cbg, true);
		Checkbox cb4 = new Checkbox("Doctorate", cbg, false);

		Label lbl = new Label("What's your primary qualification?");

		public CheckboxGroupDemo(String s)
		{
				super(s);
				setLayout(new GridLayout(6,1));
				add(lbl);
				add(cb1);
				add(cb2);
				add(cb3);
				add(cb4);
		}

		public static void main(String[] args) 
		{
			CheckboxGroupDemo fd = new CheckboxGroupDemo("Displaying Radiobuttons...");
			fd.setSize(400, 400);
			fd.show();
		}
}