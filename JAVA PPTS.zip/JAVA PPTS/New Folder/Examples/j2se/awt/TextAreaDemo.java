import java.awt.*;

class TextAreaDemo extends Frame
{
		TextArea txtComment = new TextArea(10, 20);

		Label lbl = new Label("Comments : ");

		public TextAreaDemo(String s)
		{
				super(s);
				setLayout(new FlowLayout());
				add(lbl);
				add(txtComment);
		}

		public static void main(String[] args) 
		{
			TextAreaDemo fd = new TextAreaDemo("Testing Components");
			fd.setSize(400, 400);
			fd.show();
		}
}