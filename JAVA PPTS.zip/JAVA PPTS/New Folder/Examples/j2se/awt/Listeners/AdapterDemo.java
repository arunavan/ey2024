import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code=AdapterDemo width=300 height=300>
</applet>
*/

public class AdapterDemo extends Applet
{
		String msg = "";

		// Coordinates of mouse
		int mx = 0, my = 0;

		public void init()
		{
				addMouseListener(new MAdapter(this));
				addMouseMotionListener(new MMAdapter(this));
		}

		public void paint(Graphics g)
		{
			g.drawString(msg, mx, my);
		}
}
		
class MAdapter extends MouseAdapter
{
	AdapterDemo ad;

	public MAdapter(AdapterDemo adr)
	{
		this.ad = adr;
	}

	// Handle mouse clicked
	public void mouseClicked(MouseEvent me)
	{
		ad.showStatus("Mouse Clicked.");
	}
}
		
class MMAdapter extends MouseMotionAdapter
{
	AdapterDemo mmad;

	public MMAdapter(AdapterDemo adr)
	{
		this.mmad = adr;
	}

	// Handle mouse dragged
	public void mouseDragged(MouseEvent me)
	{
		//save coordinates
		mmad.mx = me.getX();
		mmad.my = me.getY();
		mmad.msg = "*";
		mmad.showStatus("Dragging mouse at " + mmad.mx + ", " + mmad.my);
		mmad.repaint();
	}
}