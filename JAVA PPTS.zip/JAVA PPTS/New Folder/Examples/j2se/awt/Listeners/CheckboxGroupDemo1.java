import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code=CheckboxGroupDemo1 width=250 height=200></applet>*/

public class CheckboxGroupDemo1 extends Applet implements ItemListener
{
		String str = "";
		CheckboxGroup cbg;
		Checkbox cb1, cb2, cb3, cb4;

		public void init()
		{
				cbg = new CheckboxGroup();

				cb1 = new Checkbox("Undergraduate", cbg, true);
				cb2 = new Checkbox("Graduate", cbg, false);
				cb3 = new Checkbox("Post Graduate", cbg, false);
				cb4 = new Checkbox("Doctorate", cbg, false);
				
				add(cb1);
				add(cb2);
				add(cb3);
				add(cb4);

				cb1.addItemListener(this);
				cb2.addItemListener(this);
				cb3.addItemListener(this);
				cb4.addItemListener(this);
		}

		public void itemStateChanged(ItemEvent ie) 
		{
				repaint();
		}

		// Display current state of the checkboxes
		public void paint(Graphics g)
		{
				str = "Selected Checkboxes	 :	";

				str += cbg.getSelectedCheckbox().getLabel();

				g.drawString(str, 6, 70);
		}
}