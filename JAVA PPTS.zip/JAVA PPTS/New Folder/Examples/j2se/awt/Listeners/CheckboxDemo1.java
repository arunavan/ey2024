import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code=CheckboxDemo1 width=300 height=300></applet>*/

public class CheckboxDemo1 extends Applet implements ItemListener
{
		String msg = "";
		Checkbox cb1, cb2, cb3, cb4, cb5;

		Label lbl = new Label("What's your hobby?");

		public void init()
		{
				cb1 = new Checkbox("Reading");
				cb2 = new Checkbox("Music");
				cb3 = new Checkbox("Painting");
				cb4 = new Checkbox("Movies");
				cb5 = new Checkbox("Dancing");

				add(lbl);
				add(cb1);
				add(cb2);
				add(cb3);
				add(cb4);
				add(cb5);

				cb1.addItemListener(this);
				cb2.addItemListener(this);
				cb3.addItemListener(this);
				cb4.addItemListener(this);
				cb5.addItemListener(this);
		}

		public void itemStateChanged(ItemEvent ie) 
		{
				repaint();
		}
		
		public void paint(Graphics g)
		{
				msg = "Selected Checkboxes...";
				g.drawString(msg, 5, 70);
				//msg = "Reading : " + cb1.getState();
				msg =  cb1.getLabel() + " : "+ cb1.getState();
				g.drawString(msg, 5, 90);
				msg = cb2.getLabel() + " : " + cb2.getState();
				g.drawString(msg, 5, 110);
				msg = cb3.getLabel() + " : " + cb3.getState();
				g.drawString(msg, 5, 130);
				msg = cb4.getLabel() + " : " + cb4.getState();
				g.drawString(msg, 5, 150);
				msg = cb5.getLabel() + " : " + cb5.getState();
				g.drawString(msg, 5, 170);
		}
}