import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code=ButtonDemo1 width=300 height=300></applet>*/

public class ButtonDemo1 extends Applet implements ActionListener
{
		String msg = "";
		Button btnB1,  btnB2, btnB3;
	
		public void init()	
		{
				btnB1 = new Button("Yes");
				btnB2 = new Button("No");
				btnB3 = new Button("Undecided");
			
				add(btnB1);
				add(btnB2);
				add(btnB3);

				btnB1.addActionListener(this);
				btnB2.addActionListener(this);
				btnB3.addActionListener(this);
		}

		public void actionPerformed(ActionEvent ae) 
		{
				String str = ae.getActionCommand();

				if(str.equals("Yes"))
				{
						msg = "You pressed YES Button."; 
				}
				else if(str.equals("No"))
				{
						msg = "You pressed NO Button."; 
				}
				else
				{
						msg = "You pressed UNDECIDED."; 
				}

				repaint();
		}

		public void paint(Graphics g)
		{
				g.drawString(msg, 6, 100);
		}
}