import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code=ListControlDemo width=450 height=200></applet>*/

public class ListControlDemo extends Applet implements ActionListener
{
		List l1, l2;
		String msg = "";

		public void init()
		{
				l1 = new List(4, true);
				l2 = new List(5, false);

				//add item to ch1 list				
				l1.add("Amithab Bhachan");
				l1.add("Bobby Deol");
				l1.add("Sharukh Khan");
				l1.add("Rithik Roshan");
				l1.add("Leonardo DiCaprio");

				//add item to ch2 list				
				l2.add("Jaya Bhaduri");
				l2.add("Hemamalini");
				l2.add("kajol");
				l2.add("Priti Zinta");
				l2.add("Shermila");
				l2.add("New Item");

				l2.select(1);

				add(l1);
				add(l2);

				l1.addActionListener(this);
				l2.addActionListener(this);
		}

		public void actionPerformed(ActionEvent ae) 
		{
				repaint();
		}

		// Display current state of the checkboxes
		public void paint(Graphics g)
		{
				int id[];

				msg = "Selected Item from Choice ch1	 :	";

				id = l1.getSelectedIndexes();
	
				for(int i =0; i<id.length; i++)
				{
					msg += l1.getItem(id[i]) + " " ;
				}

				g.drawString(msg, 6, 100);

				msg = "Selected Item from Choice ch2	 :	";

				msg += l2.getSelectedItem();

				g.drawString(msg, 6, 120);
		}
}