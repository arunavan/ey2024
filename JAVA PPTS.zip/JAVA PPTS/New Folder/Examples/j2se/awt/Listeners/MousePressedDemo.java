import java.awt.event.*;
import java.applet.*;

/*
<applet code=MousePressedDemo width=300 height=300>
</applet>
*/

public class MousePressedDemo extends Applet
{
		public void init()
		{
				addMouseListener(new MAdapter(this));
		}
}
		
class MAdapter extends MouseAdapter
{
	MousePressedDemo mpd;

	public MAdapter(MousePressedDemo mpd)
	{
		this.mpd = mpd;
	}

	// Handle mouse clicked
	public void mousePressed(MouseEvent me)
	{
		mpd.showStatus("Mouse Pressed.");
	}
}
