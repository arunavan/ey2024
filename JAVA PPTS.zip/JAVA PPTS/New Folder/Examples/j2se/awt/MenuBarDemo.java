import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code=MenuBarDemo width=450 height=200></applet>*/

// Create a subclass of Frame
class MenuFrame extends Frame
{
		String msg ="";

		CheckboxMenuItem debug, test;

		MenuFrame(String str)
		{
				super(str);

				// Create  menu bar and add it to frame
				MenuBar mbar = new MenuBar();

				setMenuBar(mbar);

				// Create the menu items for File
				Menu mf = new Menu("File");
				
				MenuItem item1, item2, item3, item4, item5;

				mf.add(item1 = new MenuItem("New..."));
				mf.add(item2 = new MenuItem("Open..."));
				mf.add(item3 = new MenuItem("Close..."));
				mf.add(item4 = new MenuItem("-"));
				mf.add(item5 = new MenuItem("Quit..."));
			
				// Adding Menu to MenuBar
				mbar.add(mf);

				// Create the menu items for Edit
				Menu e = new Menu("Edit");
				
				MenuItem item6, item7, item8, item9;

				e.add(item6 = new MenuItem("Cut"));
				e.add(item7 = new MenuItem("Copy"));
				e.add(item8 = new MenuItem("Paste"));
				e.add(item9 = new MenuItem("-"));

				// Create the menu items for Special
				Menu s = new Menu("Special");
				
				MenuItem item10, item11, item12;

				s.add(item10 = new MenuItem("First"));
				s.add(item11 = new MenuItem("Second"));
				s.add(item12 = new MenuItem("Third"));

				// Adding Special Menu to the Edit Menu
				e.add(s);

				// These are Checkable menu items
				debug = new CheckboxMenuItem("Debug");
				e.add(debug);
				test = new CheckboxMenuItem("Testing");
				e.add(test);

				// Adding Edit Menu to MenuBar
				mbar.add(e);

				// Create an object to handle action and item events 
				MyMenuHandler handler = new MyMenuHandler(this);

				// Register it to receive those events
				item1.addActionListener(handler);
				item2.addActionListener(handler);
				item3.addActionListener(handler);
				item4.addActionListener(handler);
				item5.addActionListener(handler);
				item6.addActionListener(handler);
				item7.addActionListener(handler);
				item8.addActionListener(handler);
				item9.addActionListener(handler);
				item10.addActionListener(handler);
				item11.addActionListener(handler);
				item12.addActionListener(handler);
				debug.addItemListener(handler);
				test.addItemListener(handler);
			
				// Create an object to handle window events
				MyWindowAdapter adapter = new MyWindowAdapter(this);

				// Register it to receive those events
				addWindowListener(adapter);
		}

		public void paint(Graphics g)
		{
				g.drawString(msg, 10, 200);

				//--------------------------------------------------
					
				if(debug.getState())
				{
						g.drawString("Debug is on.", 10, 220);
				}
				else
				{
						g.drawString("Debug is off.", 10, 220);
				}

				//--------------------------------------------------

				if(test.getState())	
				{
						g.drawString("Testing is on.", 10, 240);
				}
				else
				{
						g.drawString("Testing is off.", 10, 240);
				}
		}
}

class MyWindowAdapter extends WindowAdapter
{
		MenuFrame mFrameA;

		public MyWindowAdapter(MenuFrame mF)
		{
				this.mFrameA = mF;
		}

		public void windowClosing(WindowEvent we)
		{
				mFrameA.setVisible(false);
		}
}

class MyMenuHandler implements ActionListener, ItemListener
{
		MenuFrame mFrameH;

		public MyMenuHandler(MenuFrame mF)
		{
				this.mFrameH = mF;
		}

		// Handle action events
		public void actionPerformed(ActionEvent ae)
		{
				String msg = "You selected ";

				String arg = (String)ae.getActionCommand();

				if(arg.equals("New..."))
					msg += "New.";
				else if(arg.equals("Open..."))
					msg += "Open.";
				else if(arg.equals("Close..."))
					msg += "Close.";
				else if(arg.equals("Quit..."))
					msg += "Quit.";
				else if(arg.equals("Edit"))
					msg += "Edit.";
				else if(arg.equals("Cut..."))
					msg += "Cut.";
				else if(arg.equals("Copy..."))
					msg += "Copy.";
				else if(arg.equals("Paste..."))
					msg += "Paste.";
				else if(arg.equals("First..."))
					msg += "First.";
				else if(arg.equals("Second..."))
					msg += "Second.";
				else if(arg.equals("Third..."))
					msg += "Third.";
				else if(arg.equals("Debug..."))
					msg += "Debug.";
				else if(arg.equals("Testing..."))
					msg += "Testing.";

				// Passing the String to MenuFrame class
				mFrameH.msg = msg;
				// Invoking the paint() method
				mFrameH.repaint();
		}

		// handle item events
		public void itemStateChanged(ItemEvent ie)
		{
				mFrameH.repaint();
		}
}

// Create frame Window

public class MenuBarDemo extends Applet 
{
		Frame f;

		public void init()
		{
				f = new MenuFrame("Menu Demo");

				int width = Integer.parseInt(getParameter("width"));
				int height = Integer.parseInt(getParameter("height"));
				
				setSize(new Dimension(width, height));

				f.setSize(width, height);
				f.setVisible(true);
		}

		public void start() 
		{
				f.setVisible(true);
		}

		public void stop() 
		{
				f.setVisible(false);
		}
}