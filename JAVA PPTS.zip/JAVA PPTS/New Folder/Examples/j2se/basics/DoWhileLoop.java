class DoWhileLoop
{
		public static void main(String args[])
		{
				int i = 0;

				do
				{
						System.out.println("i Value is ... :	" + i);
						i++;
				}while(i<10);

				System.out.println("");
				System.out.println("End of the do-while loop...");
		}
}