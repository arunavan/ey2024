class RelationalOperators 
{
	public static void main(String[] args) 
	{
		int x = 5, y = 8;

		System.out.println("\n Out put : Relational operators...");

		System.out.println("-------------------------------------------------------");

		System.out.println("x value is = " + x );

		System.out.println("y value is = " + y );

		System.out.println("-------------------------------------------------------");

		System.out.println("");

		System.out.println("x Less than y : ( x < y )	: " + (x<y));
		
		System.out.println("");

		System.out.println("x Greater than y : ( x > y )	 : " + (x>y));

		System.out.println("");

		System.out.println("-------------------------------------------------------");

		System.out.println("");

		System.out.println("x Less than or equal to y - ( x <= y )	 : " + (x<=y));
		
		System.out.println("");

		System.out.println("x Greater than or equal to y - ( x >= y ) : " + (x>=y));

		System.out.println("");

		System.out.println("-------------------------------------------------------");

		System.out.println("");

		System.out.println("x Equal to y - ( x == y)	: " + (x == y));

		System.out.println("");

		System.out.println("x Not Equal to y - ( x != y)	: " + (x != y));
	}
}