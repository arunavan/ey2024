public class LastIndexOfCh {
	  public static void main(String args[]) {
	  String s = "Honesty is the best Policy";
	  System.out.println(s);
	  System.out.println("lastIndexOf(b) -> " + s.lastIndexOf(98));
	  System.out.println("lastIndexOf(b) -> " + s.lastIndexOf('b'));
	  }
	}