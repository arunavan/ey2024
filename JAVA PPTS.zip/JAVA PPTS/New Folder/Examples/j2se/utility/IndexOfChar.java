public class IndexOfChar{
	  public static void main(String args[]) {
	  String s = "Honesty is the best Policy";
	  System.out.println(s);
	  System.out.println("indexOf(n, 1) -> " + s.indexOf('b', 1));
	  System.out.println("indexOf(n, 1) -> " + s.indexOf(98, 1));
	  }
	}