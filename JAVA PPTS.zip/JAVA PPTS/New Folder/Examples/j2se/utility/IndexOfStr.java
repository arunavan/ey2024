public class IndexOfStr {
	  public static void main(String args[]) {
	  String s = "That�was�the�breaking�News";
	  System.out.println(s);
	  System.out.println("indexOf(News, 5) -> " + s.indexOf("News", 5));
	  }
	}