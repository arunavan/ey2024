public class stringmethod{
    public static void main(String[] args){
		String string1 = "Hi";
		String string2 = new String("Hello");
		if (string1 == string2) {
			System.out.println("The strings are equal.");
			} else {
				System.out.println("The strings are unequal.");
				}
				}
}				