class Test14
{
	public static void main(String args[])throws Exception
	{
		Thread.sleep(1000);
		System.out.println("----hello----");
	}
}