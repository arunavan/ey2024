class Test20
{
	public static void main(String args[])
	{
		int i= Integer.parseInt("ten");
	}
}