import java.util.*;

public class ComparableDemo
{
	public static void main(String args[])
	{
		System.out.println("A".compareTo("Z"));
		System.out.println("Z".compareTo("A"));
		System.out.println("A".compareTo("A"));
		// System.out.println("A".compareTo(new Integer(10)));
	}
}