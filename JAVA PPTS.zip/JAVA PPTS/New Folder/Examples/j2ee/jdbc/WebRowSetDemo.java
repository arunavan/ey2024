/*
  * This is a basic program to demonstrate the use of a WebRowSet.
  * This example demonstrates how data present in the WebRowSet can be
  * serialized to an XML file and deserialized back again into the WebRowSet.
  */

 //Import the necessary packages.

 import java.sql.*;

 import javax.sql.*;
 import javax.sql.rowset.*;
import com.sun.rowset.*;
import java.io.*;


 public class WebRowSetDemo {
   public static void main(String args[]){


 	  Connection c ;
 	 FileWriter fWriter;
     FileReader fReader;


      try{

 	       Class.forName("oracle.jdbc.driver.OracleDriver");

 		   c = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vanikn", "infy");

 			WebRowSet sender = new WebRowSetImpl();

 			ResultSet rs;

 			Statement stmt = c.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);


		    rs = stmt.executeQuery("SELECT eno,ename,age FROM emp");

//	 		 Now populate the WebRowSet
		    sender.populate(rs);

 	         System.out.println("Size of the WebRowSet is: "+sender.size());


 	         //Delete the row with Empname as John
 	         sender.beforeFirst();
 	         while(sender.next())
 	         {
 	            if(sender.getString(2).equals("John"))
 	            {
 	               System.out.println("Deleting row with John...");
 	               sender.deleteRow();
 	                c = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vanikn", "infy");
 	               sender.setTableName("emp");
 	               sender.acceptChanges(c);
 	               break;
 	            }
 	         }

 	         // Update age of Jill
 	         sender.beforeFirst();
 	         while(sender.next())
 	         {
 	            if(sender.getString(2).equals("Jill"))
 	            {
 	               System.out.println("Updating row with Jill...");
 	               sender.updateInt(3,30);
 	               sender.updateRow();
 	               break;
 	            }
 	         }



 	         int size1 = sender.size();


 	         // data present in the WebRowSet can be serialized to an XML file

 	         fWriter = new FileWriter("EmpList.xml");
 	         sender.writeXml(fWriter);
 	         fWriter.flush();
 	         fWriter.close();

 	         // Create the receiving WebRowSet object

 	         WebRowSet receiver = new WebRowSetImpl();

 	         //Now read the XML file.

 	         fReader = new FileReader("EmpList.xml");
 	         receiver.readXml(fReader);

 	        c = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vanikn", "infy");

 	         receiver.setTableName("emp");

 	         receiver.acceptChanges(c);

 	         int size2 = receiver.size();

 	         if(size1 == size2)
 	         {
 	            System.out.println("WebRowSet serialized and de-serialiazed properly");
 	         } else {
 	            System.out.println("Error....serializing/de-serializng the WebRowSet");
 	         }

 	         sender.close();
 	         receiver.close();

 	       } catch (SQLException sqle) {
 	          System.out.println("Caught SQLException: "+sqle.getMessage());
 	       } catch (Exception e) {
 	          System.out.println("Unexpected Exception caught: "+e.getMessage());
 	       }

 	    }
 	 }