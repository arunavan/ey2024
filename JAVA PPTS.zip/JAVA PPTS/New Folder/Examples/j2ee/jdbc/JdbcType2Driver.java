//Jdbc Type2 Driver Demo
//Set the classpath to ojdbc14.jar
import java.sql.*;
public class JdbcType2Driver
{
public static void main(String[] args)
{
try
{
Class.forName("oracle.jdbc.pool.OracleDataSource");
Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost:1521:orcl","scott","tiger");
System.out.println("Connected");
}
catch(Exception e)
{
System.out.println(e);
}
}
}
