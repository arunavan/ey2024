/*
  * This is a basic program to demonstarte the functionality of a
  * FilteredRowSet. This demonstrates the basic use case of filtering out the
  * data in memory, so will avoid multiple fetches from the DB.
  */

 //Import the necessary packages.

 import java.sql.*;

 import javax.sql.*;
 import javax.sql.rowset.*;
 import javax.sql.rowset.Predicate;
 import com.sun.rowset.*;


/* Range is a class which implements an interface called Predicate.
 * Range has to override Predicate methods evaluate().
 * This class set the lower limit and the upper limit for the range of Empid's.
 */

class Range implements Predicate {

    private int lo;
    private int hi;
    private int idx;

    public Range(int  lo, int hi, int idx) {
       this.lo = lo;
       this.hi = hi;
       this.idx = idx;
    }

   public boolean evaluate(RowSet rs){
       CachedRowSet crs = (CachedRowSet)rs;
       boolean bool = false;

       // Check the present row to determine if it lies
       // within the filtering criteria.


     try{
             if ((rs.getInt(idx) >= lo) &&
               (rs.getInt(idx) <= hi)) {
                 bool = true; // within filter constraints
       } else bool = false; // outside of filter constraints
     }
     catch(SQLException e)
     {
     }
     finally{ return bool;}

   }
   public boolean evaluate(Object value,
           int column)
           throws SQLException {return true;}

   public boolean evaluate(Object value,
           String columnName)
           throws SQLException { return true;}
}


 public class FilteredRowSetDemo {
   public static void main(String args[]){


 	  Connection c ;

      try{

 	        Class.forName("oracle.jdbc.driver.OracleDriver");


 			 c = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vanikn", "infy");

 			FilteredRowSet frs = new FilteredRowSetImpl();
 			ResultSet rs;

 			Statement stmt = c.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);


		    rs = stmt.executeQuery("SELECT eno,ename,age FROM emp");

 			frs.populate(rs);

 			// Create the Range object with limits.

 			 Range storeFilter= new Range(1000,1001,1);  // 1 indicates the column position
 			 frs.setFilter(storeFilter);

 			  // After setting the filter, the contents of the rowset will
 			  // only be those rows that satisfy the filter criteria.
 			  // The EmpId's in the range 10000,10999 are filtered.
 			  // Display the contents here.

 			  while(frs.next()) {

 			     System.out.println("Emp id is: "+frs.getInt(1));
 			  }


 			   frs.close();
 			   c.close();

 		       } catch (SQLException sqle) {
 		          System.out.println("SQLException caught: "+sqle.getMessage());
 		       } catch(Exception e) {
 		          System.out.println("Unexpected exception caught: "+e.getMessage());
 		       }
 		    }
 		 }


