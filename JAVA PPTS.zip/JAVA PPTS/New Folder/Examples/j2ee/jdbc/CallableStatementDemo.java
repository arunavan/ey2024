//CallableStatement Demo
//To call a stored function f_get_sal()
import java.sql.*;
import java.io.*;

public class CallableStatementDemo
{
	public static void main(String[] args) 
	{
		try
		{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
CallableStatement  cst = con.prepareCall("{CALL ? := f_get_sal(?)}");
		cst.setInt(2, 7654);
		cst.registerOutParameter(1, Types.INTEGER);
		cst.executeUpdate();
		int sal = cst.getInt(1);
		System.out.println("Salary of	7654 Empolyee is :"+sal);
		cst.close();
		con.close();
		}
		catch(Exception e)
		{
System.out.println(e);
		}
	}
}

/*
create function f_get_sal(pempno number )return number is 
lsal number;
begin
	select sal into lsal from emp where empno = pempno;
	return lsal;
end;
*/
