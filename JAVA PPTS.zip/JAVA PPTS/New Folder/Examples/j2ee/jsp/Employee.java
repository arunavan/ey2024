package pack;
public class Employee
{
String username;
String desig;
int sal;
public void setUsername(String value)
{
username=value;
}
public void setDesig(String value)
{
desig=value;
}
public void setSal(int value)
{
sal=value;
}
public String getUsername(){return username;}
public String getDesig(){return desig;}
public int getSal(){return sal;}
}