import React from "react"
class Menu extends React.Component{

render(){


    return (

<div>
    <h1> Menu </h1>
</div>

    );
}

}


export default Menu;