import React from 'react';
const About = () => {
    return <div>About page</div>;
  };
  
  export default About;