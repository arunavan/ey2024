import React from 'react';
import ReactDOM from 'react-dom/client';

import App from './App';
import { BrowserRouter  } from 'react-router-dom';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    <App />
  </BrowserRouter>
);





/*
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {  Link , Router} from 'react-router-dom';
import { Route ,Routes} from 'react-router';
import reportWebVitals from './reportWebVitals';
import Contact from './Contact';
import Aboutus from './Aboutus';
import Menu from './Menu';
//const root = ReactDOM.createRoot(document.getElementById('root'));

const routing = (
  <Router>
  <div>    Router Example 
  <ul>

   <li>  <Link to="/"> Home </Link></li>
   <li><Link to="/menu">Menu</Link> Menu  </li>
   <li> <Link to="/aboutus">Aboutus</Link>  </li>
    <li> <Link to="/contact">Contactus</Link> </li>
   </ul>
     </div>
    <div>
      <Routes>
      <Route exact path="/" element={ <App/> }/>
      <Route path="/menu" element={ <Menu/>}/>
      <Route  path="/aboutus" element={ <Aboutus/>}/>
      <Route  path="/contact" element={ <Contact/>}/>
      </Routes> 
    </div>

  </Router>
)
//root.render(  <React.StrictMode>   <App />  </React.StrictMode>);
//const root = ReactDOM.createRoot(document.getElementById('root'));
ReactDOM.render(routing, document.getElementById('root'));  
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

*/
/*

index.js
================

import React from 'react';
import ReactDOM from 'react-dom/client';

import App from './App';
import { BrowserRouter  } from 'react-router-dom';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    <App />
  </BrowserRouter>
);


App.js
==============

import React from 'react';
import {  Routes,  Route } from 'react-router-dom';
import About from './components/About';
import Home from './components/Home';
import Contact from './components/Contact';
//import Form2 from './Form2'
import './style.css';
//npm install react-router-dom
export default function App() {
  return (
    // <Router>
      <div>
       

        <hr />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact/>}/> 
        </Routes>
        <div>
          <Form2/>
        </div>
       
      </div>
      
    // </Router>
  );
}
//http://localhost:3001/contact/123  


 <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </nav>
















*/