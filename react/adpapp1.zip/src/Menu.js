import { Component} from 'react'
export class Menu extends Component{
      render(){
      return(
        <div>
          <h1> MENU </h1>
          <h3> File    EDit     Help</h3>
        </div>
  
      );
    }
  }

 
  