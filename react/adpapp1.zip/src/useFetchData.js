import { useState, useEffect} from 'react'
//child
function useFetchData(url) { //props given parent 
    const [data, setData] = useState(null);

    // change detected 
    useEffect(() => {
      fetch(url) //axios
        .then((res) => res.json())
        .then((data) => setData(data))
        .catch((err) => console.log(`Error: ${err}`));
    }, [url]);

    return { data };
}

export default useFetchData