import React from 'react';
import {  Routes,  Route } from 'react-router-dom';
import About from './components/About';
import Home from './components/Home';
import Contact from './components/Contact';
//import Form2 from './Form2'
import './style.css';
//npm install react-router-dom
export default function App() {
  return (
    // <Router>
      <div>
       

        <hr />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact/>}/> 
        </Routes>
        <div>
          <Form2/>
        </div>
       
      </div>
      
    // </Router>
  );
}
/*http://localhost:3001/contact/123  


 <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </nav>


*/