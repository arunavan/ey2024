import React from 'react';
import './App.css';
//npm install  react-router-dom
import { Button } from 'semantic-ui-react'
import {  Routes , Route,Link } from 'react-router-dom';
import Java from '../src/components/Java'
import Oracle from '../src/components/Oracle'
import Spring from '../src/components/Spring'
import Header from './components/Header';
import ContactUs from './components/ContactUs';

function App() {
  return (
    <div className="wrapper">
      <h1>List of courses tabs</h1>
      <nav>
          <ul>
            <li><Link to="/java"><Button>Java</Button>  </Link></li>
            <li><Link to="/oracle"><Button>Oracle</Button></Link></li>
            <li><Link to="/spring"><Button>Spring</Button></Link></li>
            <li><Link to="/header">ADP HEader</Link></li>
            <li><Link to="/contactus">Connect to ADP</Link></li>
          </ul>
       </nav>
      
      
      <Routes>
            <Route exact path="/java" element={ <Java /> } />
            <Route exact  path="/oracle" element={ <Oracle />} />
            <Route exact path="/spring" element={ <Spring /> } />
            <Route exact path="/header" element={<Header/>}/>
            <Route exact path="/contactus/:id" element = {<ContactUs/> }/>

       </Routes>
     
 </div>
  );
}

export default App;

/*

 <nav>
        <ul>
          <li><a href="/java">Java</a></li>
          <li><a href="/oracle">Oracle</a></li>
          <li><a href="/spring">Spring</a></li>
          <li> <a href="/header">Header</a></li>
          <li> <a href="/contactus">ContactUs</a></li>
          
        </ul>
      </nav> 



        

      */