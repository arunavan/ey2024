import { useParams } from 'react-router-dom';
 function ContactUs(){
  const p= useParams();
    return <h2>  hr@ADP.com, {p.id }  </h2>;
  }


  export default ContactUs;