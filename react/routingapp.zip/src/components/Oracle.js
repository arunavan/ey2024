
export default function Oracle() {
  return <h2> ORacle </h2>;
}
