


export default function Java() {
   
  return <h2> Java  </h2>;
}

