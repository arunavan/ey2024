package com.staging;

public class Loan {
	
	
	int getEmi(int amount) {
		
		
		return amount/12;
	}

}
