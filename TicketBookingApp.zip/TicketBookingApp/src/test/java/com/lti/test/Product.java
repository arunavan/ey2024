package com.lti.test;

public class Product {
	
	
	public int getProductId() {
		
		return 100;
	}

	
	public String getName() {
		return "Bag";
	}
	
}
