package com.ey;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ey.components.Account;
import com.ey.components.Order;



public class AnnotationApp {

	public static void main(String[] args) {
		//IOC
		 AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(JavaComponentConfig.class);
         
         Account a1=(Account)context.getBean(Account.class);//@Component 
         a1.setId(101);
         a1.setName("Ram");
         System.out.println(a1);
         Order o=(Order)context.getBean(Order.class);
         System.out.println(o);
         System.out.println(o.hashCode());
         
         Order o1=(Order)context.getBean(Order.class);
         System.out.println(o1);
         System.out.println(o1.hashCode());

	}

}
