package com.ey;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller   //@Componnet 
public class HomeController {
	@GetMapping("/")
	public String home( Model model) {
		model.addAttribute("x", LocalDate.now());
		return "home"; //home.jsp
	}

	//@RequestMapping(value = "/user", method = RequestMethod.POST)
	@PostMapping("/user")
	public String user(@Validated User user, Model model) {
		model.addAttribute("x", user.getUserName());//mapping 
		return "user";   //result this view 
	}
}
