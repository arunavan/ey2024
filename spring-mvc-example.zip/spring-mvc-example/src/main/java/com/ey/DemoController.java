package com.ey;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller 
@RequestMapping("/mvc")
public class DemoController {
	
	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
		public String displayMessage() {
			return "welcome";   //result this view   ,view resolver 
		}

	//@RequestMapping(value = "/msg", method = RequestMethod.GET)
	@GetMapping("/msg")
	public String displayWishes() {
			return "wish";   //result this view   ,view resolver 
	}
}
