package com.adp.spring.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.adp.spring.Product;
import com.adp.spring.feign.HelloService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

//import com.adp.spring.feign.HelloService;


@RestController
@RequestMapping("/helloc")
public class HelloController {
	
//	@Autowired
//	private RestTemplate restTemplate;
	
	@Autowired
	private HelloService helloService;
	
	@Value("${eureka.instance.metadataMap.instanceId}")
	private String instanceDetails;

	@RequestMapping("/greet")//hystrix - relisiance4j
	@CircuitBreaker(name = "hello-producer", fallbackMethod = "getFallback")
	public String getGreeting(){
//		String message = restTemplate.getForObject("http://hello-producer/hellop/greet", String.class);
		
		String message = helloService.getGreetings();
		return "I am hello consumer service FROM: "+instanceDetails+"\nReceived: "+ message;
	}
	
	public String getFallback(Exception e)  {
		return "Opening circuit since hello-producer is down dummy result";
	}
}















//@RestController
//@RequestMapping("/helloc")
//public class HelloController {
//	@Autowired
//	private HelloService helloService;
//	
//	@Value("${eureka.instance.metadataMap.instanceId}")
//	private String instanceDetails;
//
//	@RequestMapping("/greet")
//	public String getGreeting(){
//		String message= helloService.getGreetings();
//		return "I am hello consumer service\n"+message+"\n FROM: "+instanceDetails;
//	}
//}
