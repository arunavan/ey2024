package com.adp.spring.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name = "hello-producer")
public interface HelloService {

    @RequestMapping("/hellop/greet")
    public String getGreetings();
}
