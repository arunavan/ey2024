package com.adp.spring.model;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

//test coverage > 70%

//@GettersAndSetters
//@Setters
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Product {
	Integer id;
	String name;
	Double price;
	
}
