package com.tcs.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin()
public class HelloWorldController {

	@RequestMapping({ "/hello" })
	public String hello() {
		return "Hello World";
	}
	@RequestMapping({ "/validate" })
	public String validate() {
		return "Validation with JWT Token is Success!";
	}
}


/*

eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3R1c2VyIiwiZXhwIjoxNzE5OTk5NzkyLCJpYXQiOjE3MTk5ODE3OTJ9.c04hyEnlPxQWCZa_ZUOv5daTGCbKnVxLKTT16c9khp83TgHFCalV5cvD5krfh7MahrHfAvU1C2rc7rimslMPCw

*/